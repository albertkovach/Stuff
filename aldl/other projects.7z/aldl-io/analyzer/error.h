#ifndef _ERROR_H
#define _ERROR_H

/************ SCOPE *********************************
  Error handling routines.
****************************************************/

void error(char *str, ...);

#endif
