#!/bin/sh

# This script runs when the consoleif interface starts ...
# Put stuff in it and set it executable to get it working.
# This is mostly intended for raspberry pi builds with a boot screen,
# which require some stuff to be done to clean up before the consoleif
# starts ...
