#!/bin/sh

# This script runs when the aldl stream first connects ...
# Put stuff in it and set it executable to get it working.

