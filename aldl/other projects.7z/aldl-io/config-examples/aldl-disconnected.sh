#!/bin/sh

# This script runs when the aldl stream first disconnects ...
# Put stuff in it and set it executable to get it working.

